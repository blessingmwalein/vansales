<?php

namespace App\Http\Controllers;

use App\Models\CustomerStop;
use Illuminate\Http\Request;

class CustomerStopController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(CustomerStop $customerStop)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CustomerStop $customerStop)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, CustomerStop $customerStop)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CustomerStop $customerStop)
    {
        //
    }
}
