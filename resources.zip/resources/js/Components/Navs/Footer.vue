<template>
    <p class="my-10 text-sm text-center text-gray-500">
        &copy; 2023 <a href="" class="hover:underline" target="_blank">Aximos</a>. All rights reserved.
    </p>
</template>